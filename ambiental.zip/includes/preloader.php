<div id="siteLoader" class="site-loader">
    <div class="preloader-content">
        <img src="assets/images/loader1.gif" alt="">
    </div>
</div>