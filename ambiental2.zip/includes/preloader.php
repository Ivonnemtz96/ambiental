<div id="siteLoader" class="site-loader">
    <div class="preloader-content">
    <img src="assets/images/preloader/1.png" alt="" class="rotate">
<img src="assets/images/preloader/2.png" alt="" class="rotate">
<img src="assets/images/preloader/3.png" alt="" class="rotate">
<img src="assets/images/preloader/4.png" alt="" class="rotate">
    </div>
</div>
